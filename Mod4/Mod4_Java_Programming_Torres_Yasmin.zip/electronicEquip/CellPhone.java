package electronicEquip;

public class CellPhone extends ElectronicEquipment
{
	public CellPhone()
	{
		super(500, 11.5, "Samsung");
		System.out.println("Weight: 173 grams");
	}
}
