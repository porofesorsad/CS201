package courses;

public class English extends Courses
{
	public English()
	{
		super("Science Fiction Literature", 256, "Famous works in science fiction literature and its impact", "English");
	}
}
