package sportStats;

public class Baseball extends Sport
{

	public Baseball() 
	{
		super("Baseball", 9);
		Sport.setDescription("Baseball is a bat-and-ball game played between two opposing teams who take turns batting and fielding. ... \n"
				+ "A player on the batting team who reaches first base without being called \"out\" can attempt to advance to subsequent \nbases as a runner, "
				+ "either immediately or during teammates' turns batting.\n");
	}

}
