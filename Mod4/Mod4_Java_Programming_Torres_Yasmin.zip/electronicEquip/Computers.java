package electronicEquip;

public class Computers extends ElectronicEquipment
{
	public Computers()
	{
		super(480, 42, "Dell");
		System.out.println("Weight: 4.6 lbs");
	}
}
