package sportStats;

public class Driver 
{

	public static void main(String[] args) 
	{
		Baseball baseball = new Baseball();
		System.out.println(baseball);
		Football football = new Football();
		System.out.println(football);
		PingPong pingPong = new PingPong();
		System.out.println(pingPong);
		Soccer soccer = new Soccer();
		System.out.println(soccer);
		

	}

}
