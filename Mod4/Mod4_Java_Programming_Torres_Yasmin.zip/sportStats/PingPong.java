package sportStats;

public class PingPong extends Sport{

	public PingPong() 
	{
		super("Ping Pong/Table Tennis", 1);
		Sport.setDescription("Players hit a lightweight ball, also known as the ping-pong ball, back and forth across a table using \nsmall rackets. "
				+ "The game takes place on a hard table divided by a net.\n");
	}

}
