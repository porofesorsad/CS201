package courses;

public class Music extends Courses
{
	public Music()
	{
		super("Music Appreciation", 121, "Music pricipals and roots", "Music");
	}
}
