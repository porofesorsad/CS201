package courses;

public class CS extends Courses
{
	public CS()
	{
		super("Computer Science l", 201, "Introduction to object oriented programming", "Science");
	}
}
