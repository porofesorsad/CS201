package courses;

public class Driver 
{
	public static void main(String[] args) 
	{
	Music music = new Music();
	System.out.println(music);
	Calc c = new Calc();
	System.out.println(c);
	CS cs = new CS();
	System.out.println(cs);
	English scifi = new English();
	System.out.println(scifi);
	}
}
