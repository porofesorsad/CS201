package Cycle;
//Yasmin Torres Module 3
public class Cycle 
{

	private int numberOfWheels = 0;
	private int weight = 0;
	
	public Cycle()
	{
		this(100, 1000);
	}
	
	public Cycle(int numberOfWheels, int weight)
	{
	this.numberOfWheels = numberOfWheels;
	this.weight = weight;	
	}
	
	public String toString()
	{
		return "Weight: " + weight + " Numer of wheels: " + numberOfWheels;
	}
	
	public static void main(String[] args) 
	{
		Cycle t1 = new Cycle();
		Cycle t2 = new Cycle(4, 1500);
		System.out.println(t1);
		System.out.println(t2);

	}

}
