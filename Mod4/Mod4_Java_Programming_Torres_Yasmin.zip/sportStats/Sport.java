package sportStats;

public class Sport 
{
private String name;
private int teamSize = 0;
private static String description;

 public Sport(String n, int s)
 {
	 name = n;
	 teamSize = s;
 }
 
 public void setName(String n)
 {
	 name = n;
 }
 
 public String getName()
 {
	 return name;
 }
 public void setSize(int s)
 {
	 teamSize = s;
 }
 
 public int getSize()
 {
	 return teamSize;
 }
 
 public static void setDescription(String d)
 {
	 description = d;
 }
 
 public String getDescription()
 {
	 return description;
 }
 public String toString()
 {
	 return "Name: " + name + "\n" + "Team size: " + teamSize + "\n" + "Description: " + description;
 }
}
