package sportStats;

public class Soccer extends Sport{

	public Soccer() 
	{
		super("Soccer", 11);
		Sport.setDescription("Two teams try to maneuver the ball into the other team's goal without using "
				+ "their hands or arms. \nThe team that scores most goals wins.\n");
	}

}
 