package courses;

public class Calc extends Courses
{
	public Calc()
	{
		super("Calculus l", 263, "Calculus fundamentals", "Math");
	}
			
}
