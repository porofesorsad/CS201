package electronicEquip;

public class Camera extends ElectronicEquipment
{
	public Camera()
	{
		super(62, 0, "Kodak");
		System.out.println("Weight: 4.16 ounces");
	}
}
