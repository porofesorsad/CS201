package sportStats;

public class Football extends Sport
{

	public Football() 
	{
		super("Football", 11);
		Sport.setDescription("Two opposing teams each defend their goals at opposite ends of a field having goal posts at each end, \n"
				+ "with points being scored chiefly by carrying the ball across the opponent's goal line "
				+ "and by place-kicking or \ndrop-kicking the ball over the crossbar between the opponent's goal posts.\n");
	}

}
